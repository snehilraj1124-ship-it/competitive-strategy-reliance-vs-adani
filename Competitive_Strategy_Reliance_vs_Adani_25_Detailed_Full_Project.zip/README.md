# Competitive Strategy Analysis — Reliance vs Adani

## Project Overview
A strategic management case study comparing two major Indian business groups through a normalized competitive scorecard, SWOT analysis, competitive moat assessment, scenario planning and strategic initiative prioritization.

## Core Question
Where does each business group have stronger strategic advantage, and what capabilities or risks should management prioritize?

## Analysis Areas
- Scale and diversification
- Vertical integration
- Digital and consumer strategy
- Infrastructure strategy
- Competitive moat
- SWOT analysis
- Growth optionality
- Capital intensity
- Strategic risk
- Scenario analysis
- Strategic initiatives
- Competitive dynamics
- Implementation roadmap
- KPI framework

## Main Strategic Insight
The case is structured around a strategic trade-off:

**Reliance → ecosystem breadth, consumer reach, digital capabilities and growth optionality**

**Adani → infrastructure depth, integration and asset-led execution**

The purpose is not to declare a universal winner, but to understand the capabilities and risks that create competitive advantage.

## Tools & Skills
- Microsoft Excel
- Strategic Analysis
- Competitive Strategy
- SWOT Analysis
- Scenario Planning
- Strategic Scorecards
- Business Strategy
- Portfolio Strategy
- Risk Analysis
- Management Consulting

## Repository Structure
```text
Competitive-Strategy-Reliance-vs-Adani/
├── README.md
├── PDF_Files/
├── Data/
└── Charts/
```

## Important Data Disclosure
This portfolio project uses a **synthetic normalized strategic scoring model**.

The scores and scenario values are analytical assumptions created for educational and portfolio demonstration. They are NOT company-reported ratings, financial forecasts, market-share figures or investment recommendations.

For a professional consulting or investment case, the model should be rebuilt using verified annual reports, industry research, market data and current company disclosures.

## Suggested LinkedIn Description
Developed a competitive strategy analysis comparing Reliance and Adani using a normalized strategic scorecard, SWOT analysis, competitive moat assessment, scenario planning and strategic initiative prioritization. Evaluated diversification, vertical integration, digital/consumer capabilities, infrastructure strength, capital intensity, execution risk and growth optionality to develop management recommendations and a 12-month strategic roadmap.
